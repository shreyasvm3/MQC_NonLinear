#!/bin/bash

for i in {3..6..1} 
do 
	j=$((10**$i))
	mkdir -p ntraj-10-$i/
	cd ntraj-10-$i/
	cp ../dyn.x ../input_mD ../run_multinode.sh .
	sed -i "s/input-ntraj/$j/g" input_mD
        sbatch run_multinode.sh
	cd ../
done
