#!/bin/bash

for i in {84..127..1} 
do 
	j=$((1525300+$i))
        scancel $j
done
