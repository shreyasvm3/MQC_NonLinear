#!/bin/bash

for i in {-1..1..1}  
do 
#	j=$(echo "scale = 1; $i/10" | bc)
# 	j=$((10**$i))
	mkdir -p c1-1.d"$i"-c2-1.d-2/
	cd c1-1.d"$i"-c2-1.d-2/
	cp ../dyn.x ../input_mD ../run_multinode.sh ../submit.sh .
	sed -i "s/input-fil/$i/g" input_mD
 	bash submit.sh
	cd ../
done
