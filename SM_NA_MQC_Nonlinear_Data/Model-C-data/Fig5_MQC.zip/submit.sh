#!/bin/bash

for i in {6..6..1} 
do 
	j=$((10**$i))
	mkdir -p ntraj-10-"$i"/
	cd ntraj-10-"$i"/
	cp ../dyn.x ../input_mD ../run_multinode.sh .
	sed -i "s/input-ntraj/$j/g" input_mD
  	for k in {1..5..1}
 	do
		mkdir -p run-$k
		cd run-$k
		cp ../dyn.x ../input_mD ../run_multinode.sh .
        	sbatch run_multinode.sh
		cd ../
        done
	cd ../
done
