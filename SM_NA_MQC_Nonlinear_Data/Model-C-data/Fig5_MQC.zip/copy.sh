#!/bin/bash

for i in 100000000 #10 100 1000 10000 100000000
do 
	j=$(echo "scale = 2; $i/100" | bc)
# 	j=$((10**$i))
	mkdir -p c1-1.d-2-c2-c3-"$j"/
	cd c1-1.d-2-c2-c3-"$j"/
	cp ../collect.sh ../gather.sh ../errorbars.f90 ../eb.out .
 	bash gather.sh
	cd ../
done
