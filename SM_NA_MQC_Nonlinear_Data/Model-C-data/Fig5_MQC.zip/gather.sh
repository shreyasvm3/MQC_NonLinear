#!/bin/bash

for i in {6..6..1} 
do 
	j=$((10**$i))
	cd ntraj-10-"$i"/
	cp ../collect.sh ../eb.out .
        bash collect.sh
        ./eb.out
        cd ../
done
