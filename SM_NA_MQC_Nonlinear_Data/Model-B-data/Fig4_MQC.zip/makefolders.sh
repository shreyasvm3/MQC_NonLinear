#!/bin/bash

for i in 60 70 80 90 #10 100 1000 10000 100000 100000000 
do 
	j=$(echo "scale = 2; $i/100" | bc)
# 	j=$((10**$i))
        mkdir -p c1-"$j"-c2-c3-1.d3/
        cd c1-"$j"-c2-c3-1.d3/
#	mkdir -p c2-c3-1.d-2-c1-"$j"/
#	cd c2-c3-1.d-2-c1-"$j"/
	cp ../dyn.x ../input_mD ../run_multinode.sh ../submit.sh .
	sed -i "s/input-fil/$j/g" input_mD
 	bash submit.sh
	cd ../
done
