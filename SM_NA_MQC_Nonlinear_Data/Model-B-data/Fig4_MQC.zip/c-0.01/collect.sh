#!/bin/bash

for i in {1..5..1} 
do 
 	j=$((111*$i))
	cd run-$i
	cp TCF.out ../"$j".out
	cd ../
done
